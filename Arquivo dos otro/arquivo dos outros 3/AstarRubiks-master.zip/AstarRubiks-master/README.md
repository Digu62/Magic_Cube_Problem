# AstarRubiks
This Python program finds the shortest solution path for a Rubik's Cube
using the A* algorithm.

AstarRubiks.py is the main program.  
Rcube.py contains required methods and must be in the same folder.

NOTE: Due to the nature of the algorithm and the problem space, any
      solution path of more than 8 rotations takes an excessive amount
      of time to complete on a typical home computer.
